# clean out junk
rm(list = ls())
gc()

# set directory
setwd("/Users/anwarmusah/Desktop/Projects/Kriging/Spatial_Analysis_Continuous_Data")

# load required libraries for Kriging
library("sf")
library("tmap")
library("raster")
library("sp")
library("gstat")
library("geoR")

# load the 393 villages from TZ and UG
STH_points <- read.csv("Soil_Transmitted_Helminth_Data.csv")

# load shapefiles for study areas for Uganda and Tanzania
study_area <- st_read("Study_Area_UG_TZ.shp")
study_area_districts <- st_read("Study_Area_UG_TZ_Districts.shp")

# STEP 1: data preparation and check distribution - let convert the CRS to meters its currently in WGS84 (Decimal degrees).
# See explanation in section 7.1.6
STH_points_sf <- st_as_sf(STH_points, coords = c("Longitude", "Latitude"), crs = 4326)
STH_points_sf_prj <- st_transform(STH_points_sf, 3857)
st_crs(STH_points_sf_prj)

# note - the shapefiles are also in WGS84, their CRS needs to be reprojected to 3857 as well
study_area_proj <- st_transform(study_area, 3857)
study_area_districts_proj <- st_transform(study_area_districts, 3857)

# remove original data to free up memory
rm(STH_points, STH_points_sf, study_area, study_area_districts)

# check distribution of points in Kenya
tm_shape(study_area_proj) + tm_polygons(alpha = 0, border.col = "black") + 
	tm_shape(STH_points_sf_prj) + tm_dots() + 
	tm_scale_bar(position = c("left","bottom")) +
	tm_compass(position = c("right", "bottom"))

# BINGO!

# STEP 2: Variogram analysis, here we need to generate a variogram plot to get an empirical variogram, in order, to then
# derive a theoretical variogram. Through this we can determine whether the fit is an Exponential, Spherical or Gaussian
# model.

# we are going to use the variogram() function which is part of the gstat package.
# For it to work, we need to coerce the our KEN_points_ss points into a sp spatial points data frame object.

STH_points_sp <- as(STH_points_sf_prj, "Spatial")
rm(STH_points_sf_prj)
# use variogram() function to compute the semivariance with a null model Prevalence as outcome
Prevalence_empirical.variogram <- variogram(Prevalence~1, STH_points_sp)
# Compute the object to reveal a table
Prevalence_empirical.variogram
# Show plot
options(scipen = 999)
plot(Prevalence_empirical.variogram)

# STEP 3: Generate theoretical semivariogram and model selection
# Note that eyeballing values for the partial sill, range and nugget, and then selecting the appropriate can be quite difficult
# therefore, allow R to do this for you and let it report the best model using the fit.variogram() function

# select the best model
best_Prevalence_theoretical.variogram <- fit.variogram(Prevalence_empirical.variogram, model = vgm(c("Exp", "Gau", "Sph")))
best_Prevalence_theoretical.variogram

# From the output (see column which says model and row 2 it highlights "Gau"), it shows that the Gaussian model is the best 
# fit with a nugget = 183.98, Partial Sill = 373.49 and Range = 88,855.17m. We therefore select the Gaussian model 
# in our Kriging to make the spatial prediction for prevalence of soil transmitted helminths

# Fit gaussian
plot(Prevalence_empirical.variogram, best_Prevalence_theoretical.variogram, 
	main  = "Gaussian model (Nug: 183.98, PSill: 373.49, Range: 88,855.17m)",
	ylab = "Semivariance", xlab = "Separation Distance [m]")

# STEP 4: Geostatistical prediction

# create an empty template
RasterTemplate <- raster(STH_points_sp)
res(RasterTemplate) <- 5000
grid.interpolation <- as(RasterTemplate, 'SpatialGrid')

# implement the statistical model
Prevalence_Gaus_Model <- gstat(formula = Prevalence~1, locations = STH_points_sp, 
	model = best_Prevalence_theoretical.variogram)

# Now, lets add the results of the interpolation to our grid template
# kriged_output will contains interpolated prevalence using the parameters and weights from Prevalence_Gaus_Model 
Kriging_output <- predict(Prevalence_Gaus_Model, grid.interpolation)

# STEP 5: Visualisation for results
bricked_output <- brick(Kriging_output)
# Separate the rasters accordingly
prevalence_gaus.prediction <- raster(bricked_output, layer = 1)
prevalence_gaus.variance <- raster(bricked_output, layer = 2)

prevalence_gaus.prediction_masked <- mask(prevalence_gaus.prediction, study_area_proj)

tm_shape(prevalence_gaus.prediction_masked) + tm_raster(title = "Predicted STH [%]", style = "cont", 
	palette = "YlOrRd") +
	tm_shape(study_area_proj) + tm_polygons(alpha = 0, border.col = "black") +
	tm_shape(STH_points_sp) + tm_dots() + 
	tm_scale_bar(position = c("left","bottom")) +
	tm_compass(position = c("left", "top")) +
	tm_layout(legend.outside = TRUE)

# let categorise values according to World Health's Organisation classification for endemicity.
# < 1% prevalance: Negligable Risk
# 1% to 10%: Low risk area
# 10% to 20%: Moderate risk areas
# 20% to 50%: High risk areas
# 50% above: Excessive risk area

reclassifyRaster <- c(-1,1,0,
	1,10,1,
	10,20,2,
	20,50,3,
	50,100,4)

# Then store the values into a matrix 
reclassifyRaster_Mat <- matrix(reclassifyRaster, ncol=3, byrow=TRUE)
prevalence_gaus.prediction_masked_rec <- reclassify(prevalence_gaus.prediction_masked, reclassifyRaster_Mat)

tm_shape(prevalence_gaus.prediction_masked_rec) + 
	tm_raster(title = "Predicted STH [%]", style = "cat", palette = c("#ffffb2", "#fecc5c", "#fd8d3c", "#f03b20", "#bd0026"), 
		labels = c("<1% [Negligable]","1-10% [Low risk]","10-20% [Moderate risk]", "20-50% [High risk]" , ">50% [Excessive risk]")) +
	tm_shape(study_area_proj) + tm_polygons(alpha = 0, border.col = "black") +
	tm_shape(STH_points_sp) + tm_dots() + 
	tm_scale_bar(position = c("left","bottom")) +
	tm_compass(position = c("left", "top")) +
	tm_layout(legend.outside = TRUE)

# You can visualise the variance using the prevalence_gaus.variance layer to see the levels of uncertainty for these predictions.