
# Solutions

# set work directory to folder
setwd("/Users/anwarmusah/Desktop/Projects/Datasets")

# load required packages
library("units")
library("dplyr")
library("tidyverse")
library("sf")
library("tmap")

# Task one

# load datasets for task one and two
all_earthquakes <- st_read("All_earthquake_points_in_Turkey.shp")
turkey_adm_areas <- st_read("gadm41_TUR_1.shp")

# first visualise to see what the data looks like
tm_shape(all_earthquakes) + tm_dots() +
	tm_shape(turkey_adm_areas) + tm_polygons(alpha = 0)

# as you can see - there are points outside the study area. Let us clip/subset them
# create a outline of the region by calculating the areas and dissolving it
turkey_adm_areas$area_est <- st_area(turkey_adm_areas)

# dissolve areas to outline
turkey_outline <- turkey_adm_areas %>% summarise(area = sum(area_est))

# subset earthquake points that are only within Turkey
turkey_earthquakes <- all_earthquakes[turkey_outline,]

# now visualise
tm_shape(turkey_outline) + tm_polygons(alpha = 0) +
	tm_shape(turkey_earthquakes) + tm_dots()

# Task two
# using the derived dataset i.e., turkey_earthquakes
# we are aggregating the points in those administrative areas i.e., turkey_adm_areas
turkey_adm_areas$total_earthquakes <- lengths(st_intersects(turkey_adm_areas, turkey_earthquakes))
# if you check the data frame
View(turkey_adm_areas)
# you can see a new column has been created with total counts of earthquakes per region. K. Maras has the highest burden of 140.

# Visualise
tm_shape(turkey_adm_areas) +
	# apply cosmetics to polygons
	tm_polygons('total_earthquakes', palette='Reds', title = "No. of Earthquakes") +
	# add the north arrow/compass to top-right handside
	tm_compass(type = "arrow", position = c("right", "top")) + 
	# add the scale bar to bottom-right handside
	tm_scale_bar(position = c("right", "bottom")) +
	# force the legend to be appear outside the plot region
	tm_layout(legend.outside = TRUE)

# Task three

# load datasets for task three
focal_earthquake_point <- st_read("Earthquake_point_in_Konya.shp")
konya_buildings <- st_read("Konya_buildings_at_risk.shp")

# visualise to inspect the data 
tm_shape(konya_buildings) + tm_polygons(alpha = 0) +
	# increased the size of the point to 0.5 and coloured it red to standout more
	tm_shape(focal_earthquake_point) + tm_dots(size = 0.5, col = "red") +
	tm_compass(type = "arrow", position = c("right", "top")) + 
	tm_scale_bar(position = c("right", "bottom"))

# change the CRS to 3857 to be in meters. This makes specifying the distance a lot easier
konya_buildings_3857 <- st_transform(konya_buildings, 3857)
focal_earthquake_point_3857 <- st_transform(focal_earthquake_point, 3857)

# create buffer for 2000m
destroyed_buffer_2000m <- st_buffer(focal_earthquake_point_3857, dist = 2000)

# second and third buffers are created for 0-5000 and 0-9000
sec_buffer_5000m <- st_buffer(focal_earthquake_point_3857, dist = 5000)
thr_buffer_9000m <- st_buffer(focal_earthquake_point_3857, dist = 9000)

# We need to use st_difference() to create the rings for 2000-5000 and 5000-9000

severe_damaged_buffer_2000_5000m <- st_difference(sec_buffer_5000m, destroyed_buffer_2000m)
partial_damaged_buffer_5000_9000m <- st_difference(thr_buffer_9000m, sec_buffer_5000m)

# ignore warning messages...

# visualise to inspect the data 
tm_shape(konya_buildings_3857) + tm_polygons(alpha = 0) +
	tm_shape(focal_earthquake_point_3857) + tm_dots(size = 0.5, col = "red") +
	# add the third ring as dashes in pink
	tm_shape(partial_damaged_buffer_5000_9000m) + tm_borders(lwd = 1.1, lty="dashed", col = "pink") + tm_polygons(col = "pink", alpha = 0.1) +
	# add the second ring as dashes in red
	tm_shape(severe_damaged_buffer_2000_5000m) + tm_borders(lwd = 1.1, lty="dashed", col = "red") + tm_polygons(col = "red", alpha = 0.1) +
	# add the 1st ring as solid red polygon with transparency of 0.4
	tm_shape(destroyed_buffer_2000m) + tm_polygons(col = "red", alpha = 0.5) +
	tm_compass(type = "arrow", position = c("right", "top")) + 
	tm_scale_bar(position = c("right", "bottom"))

# to get total buildings within each ringed region - you need to find the points or centroids of the buildings
# you can do that by using the st_centroid() function
konya_buildings_points <- konya_buildings_3857 %>% st_centroid()
# calculate number of buildings within 2000m focal point
destroyed_buffer_2000m$total_buildings <- lengths(st_intersects(destroyed_buffer_2000m, konya_buildings_points))
severe_damaged_buffer_2000_5000m$total_buildings <- lengths(st_intersects(severe_damaged_buffer_2000_5000m, konya_buildings_points))
partial_damaged_buffer_5000_9000m$total_buildings <- lengths(st_intersects(partial_damaged_buffer_5000_9000m, konya_buildings_points))

# Annotate the map by adding text
# visualise to inspect the data 

# adds buildings
tm_shape(konya_buildings_3857) + 
	tm_polygons(alpha = 0) +
# adds focal point
tm_shape(focal_earthquake_point_3857) + 
	tm_dots(size = 0.5, col = "red") +
# add the third ring as dashed line with pink zone of transparency of 0.1 for the partial damaged zone 5000-9000m
tm_shape(partial_damaged_buffer_5000_9000m) + 
	tm_borders(lwd = 1.1, lty="dashed", col = "pink") + tm_polygons(col = "pink", alpha = 0.1) +
# add the second ring as dashes with red zone of transparency of 0.1 for the severe damaged zone 2000-5000m
tm_shape(severe_damaged_buffer_2000_5000m) + 
	tm_borders(lwd = 1.1, lty="dashed", col = "red") + 
	tm_polygons(col = "red", alpha = 0.1) +
# add the 1st ring as solid red polygon with transparency of 0.4
tm_shape(destroyed_buffer_2000m) + 
	tm_polygons(col = "red", alpha = 0.5) +
# add compass
tm_compass(type = "arrow", position = c("right", "top")) +
# add scale bar
tm_scale_bar(position = c("right", "bottom")) +
# add text
tm_credits("Prevalence [%]\nPartial: 37.31%\nSevere: 11.05%\nDestroyed: 1.02%\nSurvived: 50.62%", position = c("left", "top"), size = 0.8)

# ignore warning messages...

#10734/28765 = 37.31%
#3180/28765 = 11.05%
#294/28765 = 1.02%